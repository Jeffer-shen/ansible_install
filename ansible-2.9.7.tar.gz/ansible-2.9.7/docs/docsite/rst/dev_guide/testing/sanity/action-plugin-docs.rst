action-plugin-docs
==================

Each action plugin should have a matching module of the same name to provide documentation.
